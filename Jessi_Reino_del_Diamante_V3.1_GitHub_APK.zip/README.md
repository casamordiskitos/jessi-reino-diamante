# Jessi y el Reino del Diamante — V3.1 Android

Esta carpeta está preparada para compilar el juego V3.0 como APK mediante GitHub Actions.

## Lo que hace automáticamente
- Instala Node.js y Java 17.
- Instala el Android SDK.
- Crea el proyecto Android con Capacitor.
- Copia el juego web.
- Fuerza orientación horizontal.
- Compila un APK de prueba (debug).
- Publica el APK como artefacto descargable.

## IMPORTANTE
No hace falta Android Studio.
No hace falta un PC.
La compilación se realiza en GitHub.
