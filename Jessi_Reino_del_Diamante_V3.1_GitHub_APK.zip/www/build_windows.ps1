# Requiere Node.js y npm. Instala Electron y empaqueta la carpeta www.
npm install --save-dev electron electron-builder
