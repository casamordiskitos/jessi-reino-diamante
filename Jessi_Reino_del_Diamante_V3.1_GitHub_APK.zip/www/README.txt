JESSI Y EL REINO DEL DIAMANTE — V3.0
====================================
La gran versión del proyecto.

NOVEDADES:
- 3 mundos:
  1. Bosque de Lúmina
  2. Fortaleza del Tirano
  3. Santuario del Diamante
- Progresión mediante cristales.
- Habilidad DASH.
- Más plataformas y enemigos.
- Jefe final ampliado a 10 puntos de vida.
- HUD de mundo y habilidad.
- Mejor ambientación visual por zona.
- Pantalla de título ampliada.
- Escena final más cinematográfica.
- El anillo aparece después de abrir el cofre, gira y aumenta de tamaño antes de la pregunta.
- Controles táctiles grandes para DOOGEE Tab E3 MAX.
- Preparado para PWA y empaquetado Android.

NOTA:
Este archivo sigue siendo el proyecto web jugable. Para un APK/EXE nativo hace falta un toolchain de compilación.
