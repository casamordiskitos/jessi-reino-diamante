from pathlib import Path
import re

p = Path("android/app/src/main/AndroidManifest.xml")
s = p.read_text(encoding="utf-8")

# Add landscape orientation to the main Capacitor activity.
s2 = re.sub(
    r'(<activity\b[^>]*android:name="\.MainActivity"[^>]*)(>)',
    lambda m: (m.group(1) if "android:screenOrientation" in m.group(1)
               else m.group(1) + ' android:screenOrientation="landscape"') + m.group(2),
    s,
    count=1
)

# Also request fullscreen-ish behavior through the app theme if available.
p.write_text(s2, encoding="utf-8")
print("Android manifest patched for landscape mode.")
